To distribute this package to clients do the following (you will need TortoiseSVN) 

1. Go up one directory in Windows File Explorer, right click on eMARBackup and select Export.
2. Choose a folder somewhere else on your drive (like C:\Temp\emarclient).
3. When the export is done, go to that folder (C:\Temp\emarclient) and zip up everything under
   the eMARBackup folder, including the eMARBackup folder.
4. Distribute the zip to clients along with the documentation which will be under 
   C:\Temp\emarclient\eMARBackup\docs


Folder structure

/docs		The documentation
/downloads	Area for downloaded paper MAR files (empty)
/logs		Area for log files (empty)
psftp.exe	Secure ftp command line utility
DelOld.exe	Command line utility for removing files older than a certain number of hours/days
getdate.vbs     VBScript script to return the date regardless of region
psftp.bat	Main batch file 
receipt.txt	Receipt file sent to the server upon successfull download


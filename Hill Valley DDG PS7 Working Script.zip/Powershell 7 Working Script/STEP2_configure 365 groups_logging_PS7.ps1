﻿# Import module
Import-Module ExchangeOnlineManagement

# Disable WAM broker (fixes PS7 embedded terminal auth bug)
$env:MSAL_DISABLE_WAM = "true"

# Connect to Exchange Online via device code (bypasses WAM on PS7)
Write-Host "Connecting to Exchange Online..." -ForegroundColor Cyan
Write-Host "A device login code will appear below. Open https://microsoft.com/devicelogin in your browser." -ForegroundColor Yellow
Connect-ExchangeOnline -Device -ShowBanner:$false

# File paths
$csvPath       = "C:\Users\ASridaran\OneDrive - Digacore Consulting\Documents\Hill Valley\Create DDG\Working script\DynamicDistributionGroups_new_facilities.csv"
$outputLogPath = "C:\Users\ASridaran\OneDrive - Digacore Consulting\Documents\Hill Valley\Create DDG\Working script\DDG_Settings_Results_newfacilities.csv"

# Check for input file
if (-not (Test-Path $csvPath)) {
    Write-Error "CSV file not found at path: $csvPath"
    exit
}

# Import CSV
try {
    $groups = Import-Csv -Path $csvPath
    Write-Host "Successfully imported CSV with $($groups.Count) groups."
} catch {
    Write-Error "Error importing CSV file: $_"
    exit
}

# Initialize log
$log = @()

foreach ($group in $groups) {
    $groupName = $group.GroupName

    Write-Host "`nProcessing group: $groupName" -ForegroundColor Cyan

    # Get the group object
    try {
        $groupObject = Get-UnifiedGroup -Identity $groupName -ErrorAction Stop
    } catch {
        $errorMsg = "Error: Could not find group - $($_.Exception.Message)"
        Write-Host $errorMsg -ForegroundColor Red
        $log += [PSCustomObject]@{
            GroupName       = $groupName
            Status_Settings = $errorMsg
        }
        continue
    }

    # Enable external senders + inbox delivery for members
    try {
        Set-UnifiedGroup -Identity $groupObject.Identity `
                         -HiddenFromAddressListsEnabled:$false `
                         -RequireSenderAuthenticationEnabled:$false `
                         -SubscriptionEnabled:$true `
                         -AutoSubscribeNewMembers:$true `
                         -ErrorAction Stop

        Write-Host "Successfully updated settings for: $groupName" -ForegroundColor Green
        $log += [PSCustomObject]@{
            GroupName       = $groupName
            Status_Settings = "Success"
        }
    } catch {
        $errorMsg = "Error: $($_.Exception.Message)"
        Write-Host "Error updating settings for $groupName : $errorMsg" -ForegroundColor Red
        $log += [PSCustomObject]@{
            GroupName       = $groupName
            Status_Settings = $errorMsg
        }
    }
}

# Disconnect
Disconnect-ExchangeOnline -Confirm:$false

# Export log
$log | Export-Csv -Path $outputLogPath -NoTypeInformation -Encoding UTF8
Write-Host "`nScript completed. Logged results to:`n$outputLogPath" -ForegroundColor Cyan
﻿Import-Module ExchangeOnlineManagement

$env:MSAL_DISABLE_WAM = "true"
Connect-ExchangeOnline -Device -ShowBanner:$false

$csvPath = "C:\Users\ASridaran\OneDrive - Digacore Consulting\Documents\Hill Valley\Create DDG\Working script\DynamicDistributionGroups_new_facilities.csv"
$groups  = Import-Csv -Path $csvPath

foreach ($group in $groups) {
    $groupName = $group.GroupName
    try {
        $g = Get-UnifiedGroup -Identity $groupName -ErrorAction Stop | 
             Select-Object DisplayName, 
                           PrimarySmtpAddress,
                           RequireSenderAuthenticationEnabled,
                           AutoSubscribeNewMembers,
                           SubscriptionEnabled,
                           HiddenFromAddressListsEnabled

        Write-Host "`n--- $groupName ---" -ForegroundColor Cyan
        Write-Host "External Senders Allowed : $(-not $g.RequireSenderAuthenticationEnabled)"
        Write-Host "AutoSubscribeNewMembers  : $($g.AutoSubscribeNewMembers)"
        Write-Host "SubscriptionEnabled      : $($g.SubscriptionEnabled)"
        Write-Host "Hidden From GAL          : $($g.HiddenFromAddressListsEnabled)"
    } catch {
        Write-Host "Could not find group: $groupName" -ForegroundColor Red
    }
}

Disconnect-ExchangeOnline -Confirm:$false
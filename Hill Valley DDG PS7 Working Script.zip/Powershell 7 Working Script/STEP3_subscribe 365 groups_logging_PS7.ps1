﻿Import-Module ExchangeOnlineManagement

$env:MSAL_DISABLE_WAM = "true"
Connect-ExchangeOnline -Device -ShowBanner:$false

$csvPath = "C:\Users\ASridaran\OneDrive - Digacore Consulting\Documents\Hill Valley\Create DDG\Working script\DynamicDistributionGroups_new_facilities.csv"
$outputLogPath = "C:\Users\ASridaran\OneDrive - Digacore Consulting\Documents\Hill Valley\Create DDG\Working script\DDG_Subscribe_Results.csv"

$groups = Import-Csv -Path $csvPath
$log    = @()

foreach ($group in $groups) {
    $groupName = $group.GroupName
    Write-Host "`nProcessing group: $groupName" -ForegroundColor Cyan

    try {
        $groupObject = Get-UnifiedGroup -Identity $groupName -ErrorAction Stop
    } catch {
        Write-Host "Could not find group: $groupName" -ForegroundColor Red
        $log += [PSCustomObject]@{
            GroupName        = $groupName
            MembersFound     = 0
            MembersSubscribed = 0
            Errors           = "Group not found: $($_.Exception.Message)"
        }
        continue
    }

    # Get all current members
    try {
        $members = Get-UnifiedGroupLinks -Identity $groupObject.Identity `
                                         -LinkType Members `
                                         -ResultSize Unlimited `
                                         -ErrorAction Stop
    } catch {
        Write-Host "Could not get members for: $groupName" -ForegroundColor Red
        $log += [PSCustomObject]@{
            GroupName         = $groupName
            MembersFound      = 0
            MembersSubscribed = 0
            Errors            = "Could not retrieve members: $($_.Exception.Message)"
        }
        continue
    }

    if (-not $members -or $members.Count -eq 0) {
        Write-Host "No members found in: $groupName" -ForegroundColor Yellow
        $log += [PSCustomObject]@{
            GroupName         = $groupName
            MembersFound      = 0
            MembersSubscribed = 0
            Errors            = "No members found"
        }
        continue
    }

    Write-Host "Found $($members.Count) members, subscribing..." -ForegroundColor Cyan

    $subscribedCount = 0
    $errors          = @()

    foreach ($member in $members) {
        try {
            Add-UnifiedGroupLinks -Identity $groupObject.Identity `
                                  -LinkType Subscribers `
                                  -Links $member.PrimarySmtpAddress `
                                  -ErrorAction Stop
            $subscribedCount++
            Write-Host "  Subscribed: $($member.PrimarySmtpAddress)" -ForegroundColor Green
        } catch {
            # Ignore "already subscribed" errors
            if ($_.Exception.Message -match "already") {
                $subscribedCount++
                Write-Host "  Already subscribed: $($member.PrimarySmtpAddress)" -ForegroundColor Yellow
            } else {
                $errors += "$($member.PrimarySmtpAddress): $($_.Exception.Message)"
                Write-Host "  Error subscribing $($member.PrimarySmtpAddress): $($_.Exception.Message)" -ForegroundColor Red
            }
        }
    }

    $log += [PSCustomObject]@{
        GroupName         = $groupName
        MembersFound      = $members.Count
        MembersSubscribed = $subscribedCount
        Errors            = if ($errors.Count -gt 0) { $errors -join " | " } else { "None" }
    }
}

# Disconnect
Disconnect-ExchangeOnline -Confirm:$false

# Export log
$log | Export-Csv -Path $outputLogPath -NoTypeInformation -Encoding UTF8
Write-Host "`nScript completed. Logged results to:`n$outputLogPath" -ForegroundColor Cyan
﻿# Import modules
Import-Module Microsoft.Graph.Groups
Import-Module Microsoft.Graph.Authentication
Import-Module ExchangeOnlineManagement

# Disable WAM broker (fixes PS7 embedded terminal auth bug)
$env:MSAL_DISABLE_WAM = "true"

# Connect to Microsoft Graph
Write-Host "Connecting to Microsoft Graph..." -ForegroundColor Cyan
Connect-MgGraph -Scopes "Group.ReadWrite.All", "Directory.ReadWrite.All" `
                -TenantId "3751d247-a6df-441e-8f48-0efb43857c9a" `
                -NoWelcome

# Connect to Exchange Online via device code (bypasses WAM on PS7)
Write-Host "Connecting to Exchange Online..." -ForegroundColor Cyan
Write-Host "A device login code will appear below. Open https://microsoft.com/devicelogin in your browser." -ForegroundColor Yellow
Connect-ExchangeOnline -Device -ShowBanner:$false

# File paths
$csvPath = "C:\Users\ASridaran\OneDrive - Digacore Consulting\Documents\Hill Valley\Create DDG\Working script\DynamicDistributionGroups_new_facilities.csv"
$outputLogPath = "C:\Users\ASridaran\OneDrive - Digacore Consulting\Documents\Hill Valley\Create DDG\Working script\DDG_Creation_Results_newfacilities.csv"

# Check for input file
if (-not (Test-Path $csvPath)) {
    Write-Error "CSV file not found at path: $csvPath"
    exit
}

# Import CSV
try {
    $groups = Import-Csv -Path $csvPath
    Write-Host "Successfully imported CSV with $($groups.Count) groups."
} catch {
    Write-Error "Error importing CSV file: $_"
    exit
}

# Initialize log
$log = @()

# Process each group
foreach ($group in $groups) {
    $displayName       = $group.GroupName
    $groupEmailAddress = $group.GroupEmailAddress
    $titleKeywords     = $group.TitleKeywords
    $domain            = $group.Domain
    $mailNickName      = $group.MailNickName

    # Parse TitleKeywords (semicolon-separated)
    $titles = $titleKeywords -split ";"

    # Build membership rule
    $titleRules = @()
    foreach ($title in $titles) {
        $title = $title.Trim()
        if ($title) {
            $titleRules += "(user.jobTitle -contains `"$title`")"
        }
    }

    $titleRulesCombined = $titleRules -join " or "

    $membershipRule = if ($domain) {
        "($titleRulesCombined) and (user.userPrincipalName -contains `"$domain`")"
    } else {
        "($titleRulesCombined)"
    }

    Write-Host "`nProcessing group: $displayName"
    Write-Host "Membership rule: $membershipRule"

    $statusCreate        = ""
    $statusEmail         = ""
    $emailConflictObject = ""

    # Check if group already exists
    $existingGroup = Get-MgGroup -Filter "DisplayName eq '$displayName'" -ErrorAction SilentlyContinue

    if ($existingGroup) {
        Write-Host "Group already exists: $displayName" -ForegroundColor Yellow

        try {
            Set-UnifiedGroup -Identity $displayName -PrimarySmtpAddress $groupEmailAddress -ErrorAction Stop
            $statusEmail = "Success"
            Write-Host "Updated primary SMTP address for existing group: $displayName" -ForegroundColor Green
        } catch {
            $statusEmail = "Error: $($_.Exception.Message)"
            Write-Host "Error updating email for existing group $displayName : $statusEmail" -ForegroundColor Red

            try {
                $conflict = Get-EXORecipient -ResultSize Unlimited | Where-Object {
                    $_.PrimarySmtpAddress.ToString().ToLower() -eq $groupEmailAddress.ToLower() -or
                    $_.EmailAddresses -match "(?i)SMTP:$groupEmailAddress"
                }
                $emailConflictObject = if ($conflict) {
                    "$($conflict[0].Name) ($($conflict[0].RecipientType))"
                } else {
                    "Unknown"
                }
            } catch {
                $emailConflictObject = "Error checking conflict: $($_.Exception.Message)"
            }
        }

        $log += [PSCustomObject]@{
            GroupName           = $displayName
            Status_Create       = "Skipped - Already Exists"
            Status_Email        = $statusEmail
            EmailConflictObject = $emailConflictObject
        }

        continue
    }

    # Create the dynamic Microsoft 365 group
    try {
        $bodyParams = @{
            DisplayName                   = $displayName
            MailEnabled                   = $true
            SecurityEnabled               = $true
            MailNickname                  = $mailNickName
            GroupTypes                    = @("DynamicMembership", "Unified")
            MembershipRule                = $membershipRule
            MembershipRuleProcessingState = "On"
        }

        New-MgGroup -BodyParameter $bodyParams | Out-Null
        $statusCreate = "Success"
        Write-Host "Group created: $displayName" -ForegroundColor Green
    } catch {
        $statusCreate = "Error: $($_.Exception.Message)"
        Write-Host "Error creating group $displayName : $statusCreate" -ForegroundColor Red

        $log += [PSCustomObject]@{
            GroupName           = $displayName
            Status_Create       = $statusCreate
            Status_Email        = ""
            EmailConflictObject = ""
        }
        continue
    }

    # Retry loop - wait for group to provision in Exchange Online (up to 5 minutes)
    Write-Host "Waiting for group to provision in Exchange Online..." -ForegroundColor Cyan

    $maxRetries       = 10
    $retryCount       = 0
    $groupProvisioned = $false

    while ($retryCount -lt $maxRetries -and -not $groupProvisioned) {
        Start-Sleep -Seconds 30
        $retryCount++
        Write-Host "Checking provisioning... attempt $retryCount of $maxRetries" -ForegroundColor Cyan

        try {
            Get-UnifiedGroup -Identity $displayName -ErrorAction Stop | Out-Null
            $groupProvisioned = $true
            Write-Host "Group found in Exchange Online." -ForegroundColor Green
        } catch {
            Write-Host "Not yet visible in Exchange, waiting 30 more seconds..." -ForegroundColor Yellow
        }
    }

    if (-not $groupProvisioned) {
        $statusEmail = "Error: Group never appeared in Exchange Online after $($maxRetries * 30) seconds"
        Write-Host $statusEmail -ForegroundColor Red

        $log += [PSCustomObject]@{
            GroupName           = $displayName
            Status_Create       = $statusCreate
            Status_Email        = $statusEmail
            EmailConflictObject = ""
        }
        continue
    }

    # Set primary SMTP address
    try {
        Set-UnifiedGroup -Identity $displayName -PrimarySmtpAddress $groupEmailAddress -ErrorAction Stop
        $statusEmail = "Success"
        Write-Host "Primary SMTP address set for: $displayName" -ForegroundColor Green
    } catch {
        $statusEmail = "Error: $($_.Exception.Message)"
        Write-Host "Error setting email for $displayName : $statusEmail" -ForegroundColor Red

        try {
            $conflict = Get-EXORecipient -ResultSize Unlimited | Where-Object {
                $_.PrimarySmtpAddress.ToString().ToLower() -eq $groupEmailAddress.ToLower() -or
                $_.EmailAddresses -match "(?i)SMTP:$groupEmailAddress"
            }
            $emailConflictObject = if ($conflict) {
                "$($conflict[0].Name) ($($conflict[0].RecipientType))"
            } else {
                "Unknown"
            }
        } catch {
            $emailConflictObject = "Error checking conflict: $($_.Exception.Message)"
        }
    }

    $log += [PSCustomObject]@{
        GroupName           = $displayName
        Status_Create       = $statusCreate
        Status_Email        = $statusEmail
        EmailConflictObject = $emailConflictObject
    }
}

# Disconnect sessions
Disconnect-MgGraph | Out-Null
Disconnect-ExchangeOnline -Confirm:$false

# Export log
$log | Export-Csv -Path $outputLogPath -NoTypeInformation -Encoding UTF8
Write-Host "`nScript completed. Logged results to:`n$outputLogPath" -ForegroundColor Cyan